# CleanYourTV

Android TV ke liye ek clean, tvOS-style custom launcher, plus bloatware/ads saaf karne ke adb scripts.

- **Launcher** (Kotlin + Jetpack Compose): bade rounded cards, focus par spring zoom + glow, focus kiye hue app ke rang se badalta background, live clock, aur "Most used" row jo tumhare use ke hisaab se khud badalti hai. Koi ads, koi sponsored rows nahi.
- **Scripts** (`scripts/`): adb connect, safe debloat (reversible), launcher default set karna, AdGuard DNS se system-wide ad blocking.

> Ye pura OS replace nahi karta. Bootloader unlock/root ke bina Android TV ka OS badalna possible nahi hai. Ye home screen replace karta hai aur unwanted apps hata deta hai, jo safe aur reversible hai.

## 1. Build

Android Studio (Hedgehog ya naya) me folder open karo, ya terminal se:

```bash
gradle wrapper          # pehli baar, gradlew generate karne ke liye (Gradle 8.7+)
./gradlew assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## 2. TV se connect

TV: Settings -> Device Preferences -> About -> Build number 7 baar dabao, phir Developer options me **Wireless debugging** on karo.

```bash
# Android 11+ (pairing zaroori):
adb pair <tv-ip>:<pairing-port>        # TV pe "Pair with pairing code" wala port + 6-digit code
./scripts/connect.sh <tv-ip>:<wireless-debugging-port>

# Purane Android TV (adb over network, port 5555):
./scripts/connect.sh <tv-ip>:5555
```

TV pe "Allow debugging?" popup aaye to **Always allow**.

## 3. Launcher install

```bash
./scripts/set-launcher.sh
```

Agar TV default home na badle: Home dabao, popup me CleanYourTV chuno aur "Always". Kuch Google TV builds stock launcher ko force karte hain; us case me stock launcher ko disable karna padta hai (`pm disable-user --user 0 <launcher-package>`), lekin pehle `adb shell cmd package resolve-activity -a android.intent.action.MAIN -c android.intent.category.HOME` se package confirm karo aur ye tabhi karo jab CleanYourTV install ho chuka ho.

## 4. Debloat

```bash
./scripts/debloat.sh scan                       # list + suggestions
./scripts/debloat.sh remove <package> [...]     # har package pe confirm puchta hai
./scripts/debloat.sh restore <package>          # galti ho gayi to wapas
```

Protected packages (settings, systemui, gms, vending, providers...) script khud skip karta hai.

## 5. Ads

```bash
./scripts/ads-dns.sh on     # AdGuard DNS
./scripts/ads-dns.sh off
```

Ye DNS-level ads/trackers rokta hai. Apps ke andar ke in-stream ads (jaise YouTube) isse nahi hatenge.

## Status

v0.1: home screen, app launch, most-used row, dynamic background. Pehle TV pe test karke feedback ke hisaab se aage badhenge (wallpapers, pinned apps, widgets, settings shortcut).
