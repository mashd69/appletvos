#!/usr/bin/env bash
# Usage: ./scripts/set-launcher.sh [path/to/app-debug.apk]
# APK install karta hai aur CleanYourTV ko default Home banane ki koshish karta hai.
set -euo pipefail

apk="${1:-app/build/outputs/apk/debug/app-debug.apk}"
[[ -f "$apk" ]] || { echo "APK nahi mila: $apk (pehle ./gradlew assembleDebug chalao)" >&2; exit 1; }

adb install -r "$apk"
adb shell cmd package set-home-activity com.cleanyourtv.launcher/.MainActivity \
  || echo "set-home-activity is TV pe kaam nahi kiya. TV pe Home dabao, 'CleanYourTV' chuno aur 'Always' dabao."
adb shell input keyevent KEYCODE_HOME

cat <<'EOF'

Default wapas stock launcher pe karna ho:
  adb shell pm clear com.cleanyourtv.launcher   # ya
  adb uninstall com.cleanyourtv.launcher
EOF
