#!/usr/bin/env bash
# TV ka bloatware hatane ka safe tareeka. Kuch bhi apne aap nahi hatta.
#
#   ./scripts/debloat.sh scan                 # packages ki list file me save + suspicious dikhao
#   ./scripts/debloat.sh remove <pkg> [...]   # confirm karne ke baad current user se hatao (reversible)
#   ./scripts/debloat.sh restore <pkg> [...]  # wapas lao
#
# `pm uninstall -k --user 0` app ko sirf current user se hatata hai; system image me
# APK rehti hai, isliye `restore` ya factory reset se app wapas aa jata hai.
set -euo pipefail

command -v adb >/dev/null || { echo "adb nahi mila" >&2; exit 1; }

# In packages ko kabhi nahi hatayenge: TV bricks ya bootloop ho sakta hai.
PROTECTED='^(android|com\.android\.(systemui|settings|providers\..*|tv\.settings|inputdevices|shell|packageinstaller|permissioncontroller|bluetooth|networkstack.*|server\.telecom)|com\.google\.android\.(gms|gsf|tv\.provision.*|packageinstaller|permissioncontroller|webview)|com\.android\.vending|com\.cleanyourtv\.launcher)$'

# Scan sirf hint deta hai, faisla tumhara hai.
HINTS='(ads?|advert|promo|demo|store|shop|deals|stub|bloat|tracking|analytic|telemetry|hotstar|netflix|prime|youtube\.tv|gallery|music|game)'

cmd="${1:-}"; shift || true

case "$cmd" in
  scan)
    out="packages-$(date +%Y%m%d-%H%M%S).txt"
    adb shell pm list packages -f > "$out"
    echo "Poori list save hui: $out ($(wc -l < "$out") packages)"
    echo
    echo "== User-installed (-3) =="
    adb shell pm list packages -3 | sed 's/^package://' | sort
    echo
    echo "== System packages jinke naam me hint mila (sirf suggestion) =="
    adb shell pm list packages -s | sed 's/^package://' | grep -Ei "$HINTS" | sort || true
    ;;

  remove)
    [[ $# -gt 0 ]] || { echo "Usage: $0 remove <package> [...]" >&2; exit 1; }
    for pkg in "$@"; do
      if [[ "$pkg" =~ $PROTECTED ]]; then
        echo "SKIP  $pkg  (protected, TV ke liye zaroori)"; continue
      fi
      if ! adb shell pm list packages | grep -qx "package:$pkg"; then
        echo "SKIP  $pkg  (installed nahi hai)"; continue
      fi
      read -r -p "Hatana hai $pkg ? [y/N] " ans
      if [[ "$ans" =~ ^[Yy]$ ]]; then
        adb shell pm uninstall -k --user 0 "$pkg" && echo "OK    $pkg hata diya"
      else
        echo "SKIP  $pkg"
      fi
    done
    ;;

  restore)
    [[ $# -gt 0 ]] || { echo "Usage: $0 restore <package> [...]" >&2; exit 1; }
    for pkg in "$@"; do
      adb shell cmd package install-existing "$pkg"
    done
    ;;

  *)
    sed -n '2,10p' "$0"
    exit 1
    ;;
esac
