#!/usr/bin/env bash
# System-wide ad/tracker blocking, Private DNS (DNS-over-TLS) se. App ya root ki zaroorat nahi.
#   ./scripts/ads-dns.sh on     # AdGuard DNS
#   ./scripts/ads-dns.sh off    # default pe wapas
set -euo pipefail

case "${1:-}" in
  on)
    adb shell settings put global private_dns_specifier dns.adguard-dns.com
    adb shell settings put global private_dns_mode hostname
    echo "Private DNS: dns.adguard-dns.com (AdGuard) on"
    ;;
  off)
    adb shell settings put global private_dns_mode opportunistic
    adb shell settings delete global private_dns_specifier || true
    echo "Private DNS default pe wapas"
    ;;
  *)
    echo "Usage: $0 on|off" >&2; exit 1 ;;
esac

# Note: ye sirf DNS-level ads rokta hai. YouTube jaise apps ke in-stream ads isse nahi hatenge.
