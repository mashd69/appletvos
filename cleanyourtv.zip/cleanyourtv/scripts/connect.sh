#!/usr/bin/env bash
# Usage: ./scripts/connect.sh <tv-ip>[:port]
# Wireless debugging port TV pe dikhta hai (Developer options -> Wireless debugging).
set -euo pipefail

if ! command -v adb >/dev/null; then
  echo "adb nahi mila. Install karo: platform-tools (https://developer.android.com/tools/releases/platform-tools)" >&2
  exit 1
fi

target="${1:-}"
if [[ -z "$target" ]]; then
  echo "Usage: $0 <tv-ip>[:port]   (jaise 192.168.1.70:5555)" >&2
  exit 1
fi
[[ "$target" == *:* ]] || target="$target:5555"

adb connect "$target"
echo "--- devices ---"
adb devices

echo "--- TV info ---"
adb -s "$target" shell getprop ro.product.manufacturer
adb -s "$target" shell getprop ro.product.model
adb -s "$target" shell getprop ro.build.version.release
