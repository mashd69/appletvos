package com.cleanyourtv.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class TvApp(
    val label: String,
    val packageName: String,
    val launchIntent: Intent,
    val image: ImageBitmap,
    /** true = 16:9 banner, false = square icon (card me centre me dikhega). */
    val isBanner: Boolean,
    /** Background tint ke liye 0..360 hue, package name se deterministic. */
    val hue: Float,
)

object AppRepository {

    fun load(context: Context): List<TvApp> {
        val pm = context.packageManager
        val own = context.packageName

        fun query(category: String): List<ResolveInfo> =
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(category), 0)

        // Pehle TV apps (leanback), phir phone-only apps jo sirf LAUNCHER declare karte hain.
        val leanback = query(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val leanbackPackages = leanback.map { it.activityInfo.packageName }.toSet()
        val phoneOnly = query(Intent.CATEGORY_LAUNCHER)
            .filter { it.activityInfo.packageName !in leanbackPackages }

        return (leanback.map { it to true } + phoneOnly.map { it to false })
            .filter { (info, _) -> info.activityInfo.packageName != own }
            .distinctBy { (info, _) -> info.activityInfo.packageName }
            .map { (info, isLeanback) -> toTvApp(context, info, isLeanback) }
            .sortedBy { it.label.lowercase() }
    }

    private fun toTvApp(context: Context, info: ResolveInfo, isLeanback: Boolean): TvApp {
        val pm = context.packageManager
        val pkg = info.activityInfo.packageName
        val banner = if (isLeanback) info.activityInfo.loadBanner(pm) else null
        val drawable = banner ?: info.activityInfo.loadIcon(pm)
        val isBanner = banner != null
        val bitmap = if (isBanner) drawable.toBitmap(640, 360) else drawable.toBitmap(256, 256)

        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(if (isLeanback) Intent.CATEGORY_LEANBACK_LAUNCHER else Intent.CATEGORY_LAUNCHER)
            .setClassName(pkg, info.activityInfo.name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)

        return TvApp(
            label = info.loadLabel(pm).toString(),
            packageName = pkg,
            launchIntent = intent,
            image = bitmap.asImageBitmap(),
            isBanner = isBanner,
            hue = ((pkg.hashCode() % 360) + 360) % 360f,
        )
    }
}

/** Kaunsa app kitni baar khola gaya, taaki "Most used" row dynamic rahe. */
object UsageStore {
    private const val PREFS = "usage"

    fun bump(context: Context, packageName: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt(packageName, prefs.getInt(packageName, 0) + 1).apply()
    }

    fun count(context: Context, packageName: String): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(packageName, 0)
}
