package com.cleanyourtv.launcher

import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.Date

private val CardWidth = 272.dp
private val CardHeight = 153.dp

@Composable
fun HomeScreen(refreshKey: Int) {
    val context = LocalContext.current

    var apps by remember { mutableStateOf<List<TvApp>>(emptyList()) }
    LaunchedEffect(refreshKey) {
        apps = withContext(Dispatchers.Default) { AppRepository.load(context) }
    }

    // Home button dabane par launcher band na ho.
    BackHandler(enabled = true) {}

    // Focus kiye hue app ke hisaab se background ka rang smoothly badalta hai.
    var hue by remember { mutableFloatStateOf(215f) }
    val tint by animateColorAsState(
        targetValue = Color.hsv(hue, 0.55f, 0.38f),
        animationSpec = tween(durationMillis = 700),
        label = "background",
    )

    val mostUsed = remember(apps, refreshKey) {
        apps.map { it to UsageStore.count(context, it.packageName) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
            .take(10)
            .map { it.first }
    }

    val onFocused: (TvApp) -> Unit = { hue = it.hue }
    val onLaunch: (TvApp) -> Unit = { app ->
        UsageStore.bump(context, app.packageName)
        runCatching { context.startActivity(app.launchIntent) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(tint, Color.Black)))
            .padding(top = 28.dp),
    ) {
        TopBar()

        if (mostUsed.isNotEmpty()) {
            SectionTitle("Most used")
            AppRow(mostUsed, onFocused, onLaunch)
        }
        SectionTitle("All apps")
        AppRow(apps, onFocused, onLaunch)
    }
}

@Composable
private fun TopBar() {
    val context = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = Date()
            delay(15_000)
        }
    }
    val time = DateFormat.getTimeFormat(context).format(now)
    val date = DateFormat.format("EEEE, d MMMM", now).toString()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 56.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = "CleanYourTV",
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 22.sp,
            fontWeight = FontWeight.SemiBold,
        )
        Column(horizontalAlignment = Alignment.End) {
            Text(text = time, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Light)
            Text(text = date, color = Color.White.copy(alpha = 0.65f), fontSize = 16.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        color = Color.White.copy(alpha = 0.9f),
        fontSize = 24.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 56.dp, top = 28.dp, bottom = 4.dp),
    )
}

@Composable
private fun AppRow(
    apps: List<TvApp>,
    onFocused: (TvApp) -> Unit,
    onLaunch: (TvApp) -> Unit,
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 56.dp, vertical = 24.dp),
        horizontalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        items(apps, key = { it.packageName }) { app ->
            AppCard(app, onFocused, onLaunch)
        }
    }
}

@Composable
private fun AppCard(
    app: TvApp,
    onFocused: (TvApp) -> Unit,
    onLaunch: (TvApp) -> Unit,
) {
    var focused by remember { mutableStateOf(false) }

    // tvOS jaisa spring zoom.
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.14f else 1f,
        animationSpec = spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMediumLow),
        label = "scale",
    )
    val labelAlpha by animateFloatAsState(if (focused) 1f else 0f, label = "labelAlpha")
    val shape = RoundedCornerShape(22.dp)

    Column(
        modifier = Modifier.width(CardWidth),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(CardWidth, CardHeight)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                }
                .shadow(if (focused) 28.dp else 0.dp, shape)
                .clip(shape)
                .background(Color(0xFF2C2C2E))
                .border(if (focused) 3.dp else 0.dp, Color.White.copy(alpha = 0.9f), shape)
                // onFocusChanged clickable se PEHLE aana chahiye, tabhi focus state milti hai.
                .onFocusChanged {
                    focused = it.isFocused
                    if (it.isFocused) onFocused(app)
                }
                .clickable { onLaunch(app) },
            contentAlignment = Alignment.Center,
        ) {
            Image(
                bitmap = app.image,
                contentDescription = app.label,
                contentScale = if (app.isBanner) ContentScale.Crop else ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (app.isBanner) 0.dp else 28.dp),
            )
        }

        Text(
            text = app.label,
            color = Color.White.copy(alpha = labelAlpha),
            fontSize = 18.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .padding(top = 18.dp)
                .height(24.dp),
        )
    }
}
